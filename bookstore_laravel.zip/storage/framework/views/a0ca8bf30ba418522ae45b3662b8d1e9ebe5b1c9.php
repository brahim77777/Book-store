<?php $__env->startSection('head'); ?>
    <link href="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
    المؤلفون
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('authors.create')); ?>" class="btn btn-primary">
        اضف مؤلفا جديدا
        <i class="fas fa-plus"></i>

    </a>
    <hr>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped table-bordered text-right " cellspacing="0" width="100%" id="authors-table">
                <thead>
                <tr>
                    <th>الاسم</th>
                    <th>الوصف</th>
                    <th>خيارات</th>
                </tr>

                <tbody>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($author->name); ?></td>
                        <td><?php echo e($author->description); ?></td>
                        <td>
                            <a class="btn btn-info btn-sm" href="<?php echo e(route('authors.edit' , $author)); ?>" ><i class="fa fa-edit"></i> تعديل</a>
                            <form action="<?php echo e(route('authors.destroy' , $author)); ?>" method="post" class="d-inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('هل انت متأكد ؟')"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </thead>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('theme/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <script>
        $('#authors-table').DataTable({
            "language":{
                "url": "//cdn.datatables.net/plug-ins/1.13.5/i18n/ar.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brahim/act311/bookstore_laravel/resources/views/admin/authors/index.blade.php ENDPATH**/ ?>