<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body dir="rtl">
<p>مرحبًا <?php echo e($user->name); ?></p>
<p>لقد استلمنا طلبك بنجاح</p>
<br/>

<table style="width: 600px; text-align:right">
    <thead>
    <tr>
        <th>عنوان الكتاب</th>
        <th>السعر</th>
        <th>عدد النسخ</th>
        <th>السعر الإجمالي</th>
    </tr>
    </thead>
    <tbody>
    <?php
        $subTotal = 0
    ?>
    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->title); ?></td>
            <td><?php echo e($product->price); ?>$</td>
            <td><?php echo e($product->pivot->number_of_copies); ?></td>
            <td><?php echo e($product->price * $product->pivot->number_of_copies); ?>$</td>
            <?php
                $subTotal += $product->price * $product->pivot->number_of_copies
            ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <tr>
        <td colspan="3" style="border-top:1px solid #ccc;"></td>
        <td style="font-size:15px;font-weight:bold;border-top:1px solid #ccc;">المجموع الكلي : $<?php echo e($subTotal); ?></td>
    </tr>
    </tbody>
</table>

</body>
</html>
<?php /**PATH /home/brahim/act311/bookstore_laravel/resources/views/mails/order-mail.blade.php ENDPATH**/ ?>