<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">المؤلفون</div>

                <div class="card-body">
                    <div class="row justify-content-center" >
                        <form action="<?php echo e(route('gallery.author.search')); ?>" method="get">
                            <div class="row d-flex justify-content-center form-group ">
                                <input type="text" class="col-6 ml-2 " name="term" placeholder="البحث">
                                <button type="submit" class="col-4  btn btn-info ">ابحث</button>
                            </div>
                        </form>
                    </div>
                    <hr>
                    <br>

                    <h3 class="mb-4"><?php echo e($title); ?></h3>
                    <?php if($authors->count()): ?>
                        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a style='color:grey' href="<?php echo e(route('gallery.author.show' , $author)); ?>">
                                <li class="list-group-item">
                                    <?php echo e($author->name); ?>

                                    (<?php echo e($author->books()->count()); ?>)
                                </li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-12 alert alert-info mt-4 mx-auto text-center">
                            لا نتائج
                        </div>
                    <?php endif; ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brahim/act311/bookstore_laravel/resources/views/authors/index.blade.php ENDPATH**/ ?>